package com.boa.circuitbreakerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CircuitbreakerdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CircuitbreakerdemoApplication.class, args);
	}

}
