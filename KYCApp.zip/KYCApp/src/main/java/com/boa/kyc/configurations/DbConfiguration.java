package com.boa.kyc.configurations;



import java.util.Properties;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnResource;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Conditional;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.mongodb.MongoClient;

@Configuration
//@Profile("prod")
public class DbConfiguration {
	
	@Value("${DATABASE_URL}")
	String url;
	
	@Value("${DATABASE_USERNAME}")
	String username;
	
	@Value("${DATABASE_PASSWORD}")
	String password;
	
	
	@Bean
	@ConditionalOnClass(DataSource.class)
    public DataSource getMysqlDataSource() {
        DataSourceBuilder dataSourceBuilder = DataSourceBuilder.create();
        //dataSourceBuilder.driverClassName("com.mysql.jdbc.Driver");
        dataSourceBuilder.url(url);
        dataSourceBuilder.username(username);
        dataSourceBuilder.password(password);
        return dataSourceBuilder.build();
    }
	
	
	//usemysql=local
	@Bean
	@ConditionalOnProperty(
	  name = "usemysql", 
	  havingValue = "local")
	@ConditionalOnMissingBean
	public DataSource dataSource() {
	    DriverManagerDataSource dataSource = new DriverManagerDataSource();
	  
	    dataSource.setDriverClassName("com.mysql.jdbc.Driver");
	    dataSource.setUrl("jdbc:mysql://localhost:3306/boatestDb?createDatabaseIfNotExist=true");
	    dataSource.setUsername("root");
	    dataSource.setPassword("vignesh");
	 
	    return dataSource;
	}
	
	
	
	@Bean
	    @Conditional(JDBCDataTypeCondition.class)
	    public TransactionData jdbcTransactions(){
		 System.out.println("Entering jdbc....");
	        return new JDBCTransactionImpl();
	    }
	 
	    @Bean
	    @Conditional(MongoDataTypeCondition.class)
	    public TransactionData mongoTransactions(){
	    	 System.out.println("Entering mongodb....");
	        return new MongoTransactionImpl();
	    }
}
