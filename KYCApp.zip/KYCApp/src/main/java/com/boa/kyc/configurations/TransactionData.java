package com.boa.kyc.configurations;

import java.util.List;

public interface TransactionData {

	List getAllTransactions();
}
