package com.boa.kyc.KYCApp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
//import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
//import org.springframework.test.context.ContextConfiguration;
//import org.springframework.test.context.support.AnnotationConfigContextLoader;

import com.boa.kyc.configurations.DbConfiguration;
import com.boa.kyc.models.MongoTransaction;

//@EnableDiscoveryClient
@SpringBootApplication
//@EnableAutoConfiguration
@ComponentScan(basePackages="com.boa.kyc.*")
@EnableJpaRepositories(basePackages="com.boa.kyc.*") 
@EnableMongoRepositories(basePackages="com.boa.kyc.*" )
@EntityScan(basePackages="com.boa.kyc.*")

public class KycAppApplication{

	
	public static void main(String[] args) {
		
		//SpringApplication.run(KycAppApplication.class, args);
		//just doing this programmatically for demo
        String[] appArgs = {"--debug"};

       SpringApplication app = new SpringApplication(KycAppApplication.class);
       
       app.setLogStartupInfo(false);
       app.run(appArgs);
	}
	

}

