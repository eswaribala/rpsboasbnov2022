package com.boa.kyc.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boa.kyc.models.Account;
import com.boa.kyc.models.Customer;
import com.boa.kyc.repositories.AccountRepository;
import com.boa.kyc.repositories.CustomerRepository;

@Service
public class AccountService {

	@Autowired
	private AccountRepository actRepo;
	@Autowired
	private CustomerService customeService;
	
	//add the account
		public Account addAccount(Account account, int customerId)
		{
			Customer customer =customeService.getCustomerById(customerId);
			account.setCustomer(customer);
			return actRepo.save(account);			
			
		}
		
		//account by id
		
		public Account getAccountById(int id)
		{
			return actRepo.findById(id).orElse(null);
		}
		
		//select all
		
		public List<Account> gerAllAccounts()
		{
			return actRepo.findAll();
		}
}
