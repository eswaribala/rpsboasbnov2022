package com.boa.kyc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.models.Account;
import com.boa.kyc.models.Customer;
import com.boa.kyc.services.AccountService;

@RestController
public class AccountController {

    @Autowired
	private AccountService accountService;
	//adding the customer
	@CrossOrigin("*")
	@PostMapping("/addaccount/{Id}")
	public @ResponseBody Account addAccountData(@RequestBody Account account,@PathVariable int Id)
	{
		
		return this.accountService.addAccount(account, Id);
	}
	//getall
	@CrossOrigin("*")
	@GetMapping(path="/getallaccounts",produces=MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody List<Account> getAllAccountData()
	{
		
		return this.accountService.gerAllAccounts();
	}
	//getaccount byid
	@CrossOrigin("*")
	@GetMapping("/getaccountbyid/{id}")
	public @ResponseBody Account getAccountDataById(@PathVariable  int id )
	{
		
		return this.accountService.getAccountById(id);
	}
}
