package com.boa.kyc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.boa.kyc.configurations.DbConfiguration;
import com.boa.kyc.models.Customer;
import com.boa.kyc.models.MongoTransaction;
import com.boa.kyc.services.CustomerService;

import brave.sampler.Sampler;

@RestController
public class CustomerController {

	@Autowired
    private DbConfiguration dbConfig;
	@Autowired
	private CustomerService customerService;
	@Autowired
    private ApplicationContext applicationContext;
	
	@Value("${message}")
	String message;
	
	
	@GetMapping("/conditionaltran")
	public List getAllTransactions()
	{
		 System.out.println(message);
		return dbConfig.mongoTransactions().getAllTransactions();
		
	}
	
	 @Bean
	    public Sampler alwaysSampler() {
	        return Sampler.ALWAYS_SAMPLE;
	    }
	
	
	@GetMapping("/beans")
    public String[] beans() {
     System.out.println(message);


        String[] beanNames = applicationContext.getBeanDefinitionNames();

        for (String beanName : beanNames) {

            System.out.println(beanName + " : " + applicationContext.getBean(beanName).getClass().toString());
           
        
        }

       

        return beanNames;
    }
	
	//adding the customer
	@CrossOrigin("*")
	@PostMapping("/addcustomer")
	public @ResponseBody Customer addCustomerData(@RequestBody Customer customer)
	{
		
		return this.customerService.addCustomer(customer);
	}
	//getall
	@CrossOrigin("*")
	@GetMapping("/getallcustomers")
	public @ResponseBody List<Customer> getAllCustomerData()
	{
		
		return this.customerService.gerAllCustomers();
	}
	//getcustomer byid
	@CrossOrigin("*")
	@GetMapping("/getcustomerbyid/{id}")
	public @ResponseBody Customer getCustomerDataById(@PathVariable  int id )
	{
		
		return this.customerService.getCustomerById(id);
	}
	
	//delete customer
	//getcustomer byid
	@CrossOrigin("*")
	@GetMapping("/deletecustomerbyid/{id}")
	public void deleteCustomerDataById(@PathVariable  int id )
		{
			
			this.customerService.deleteCustomerById(id);
		}
	
	@CrossOrigin("*")
	@GetMapping("/updatecustomerfirstname/{Id}/{fname}")
	public void updateCustomerFirstName(@PathVariable  int Id , @PathVariable String fname)
		{
			
			this.customerService.updateFirstName(Id, fname);
		}
	
	
	// Update Customer
	@PutMapping("/updatecustomer/{id}")
	public Customer updateCustomer(@PathVariable(value = "id") int id,
	                                         @RequestBody Customer customer) {

	    Customer cust = this.customerService.getCustomerById(id);
	            
        cust.setCustomerId(id);
	    cust.setFirstName(customer.getFirstName());
	    cust.setLastName(customer.getLastName());
	    cust.setDob(customer.getDob());
	    cust.setAddrress(customer.getAddress());

	    Customer updatedCustomer = this.customerService.addCustomer(cust);
	    return updatedCustomer;
	}
	
}
