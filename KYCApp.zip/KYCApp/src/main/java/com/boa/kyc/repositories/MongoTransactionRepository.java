package com.boa.kyc.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.transaction.annotation.Transactional;

import com.boa.kyc.models.MongoTransaction;
@Transactional
public interface MongoTransactionRepository extends MongoRepository<MongoTransaction,Integer>{

}
